# GT-SAMPLE-01 ガスタービン設計アプリ共通サンプル

一軸・遠心圧縮機2段・単管燃焼器1缶・軸流タービン3段の仮想機です。代表の定格条件は軸回転数39,000 rpm、入口空気流量0.700 kg/s。圧縮機の全機全圧比は3.2、第1段の対数全圧比配分は50%です。各アプリの計算とデータ受け渡しを同じ案件・設計版で確認できます。

## まずDesign Deskで確認する

設計アプリを格納した共通フォルダーで、PowerShellから下記を実行します。コピーするため、サンプル原本は繰り返し使えます。ブラウザで `http://127.0.0.1:8773/` を開き、`GT-SAMPLE-01` の「設計成果物」「評価断面」「要求・検証」を確認します。

```powershell
$sample = (Resolve-Path 'artifacts/gas-turbine-sample-20261128').Path
$sampleDb = Join-Path $env:TEMP ("GT-SAMPLE-01-" + [guid]::NewGuid() + ".sqlite3")
Copy-Item -LiteralPath (Join-Path $sample 'design-desk.sqlite3') -Destination $sampleDb
python gas_turbine_manager/server.py --data $sampleDb --port 8773
```

台帳には定格通しケース、基準・燃焼器反映後・冷却後・遠心翼寸法の各サイクル、翼形状、二次空気、評価断面照合が登録済みです。翼形状と二次空気から、それぞれの入力元サイクルを確認できます。仮想ケースのため、実機設計の承認は判定保留になります。案件JSONを別台帳に取り込むと新しい案件IDが発行されます。同じIDで検証する場合はサンプル台帳のコピーを使ってください。

## 各アプリで開くファイル

Webアプリの起動には共通ランチャーの `python -m gas_turbine_cycle_app.tools.suite_launcher start <起動名>` を使えます。Design Deskは上のコマンドで別台帳を起動してください。

| アプリ | 起動名と読み込むファイル | 確認する結果 |
|---|---|---|
| Cycle Studio | `cycle`。基準から再計算する場合は `cycle-input.json`。冷却後の状態を開く場合は `rated/cycle-cooled.json` | 39,000 rpm、0.700 kg/s、冷却後正味出力 |
| 遠心翼設計 | `blade`。 `native/compressor.json` をプロジェクトとして開く | インペラー1 → 翼付きディフューザ1 → 翼付きリターンチャネル → インペラー2 → 翼付きディフューザ2 → 90°転向後の軸方向ガイドベーン |
| 単管燃焼器 | `combustor`。Cycle Studioの「設計アプリ連携」で `rated/cycle-base.json` を入力し、`settings/combustor.json` を設定欄に入れる | 燃焼器出口全温1,123 K、孔群の空気配分、全圧損失、出口区画温度 |
| 軸流タービン | `turbine`。 `native/axial-turbine.json` を読み込む | 回転数39,000 rpm、動翼3列・静翼3列、段仕事。排気ディフューザは `rated/turbine.json` の連携結果を参照 |
| Secondary Air Network | `secondary-air`。 `native/secondary-air.json` を読み込む | 圧縮機第2段の抽気、翼冷却6枝と段間パージ2枝。収束履歴と注入点は `rated/cooling.json` |
| 油配管 | `oil`。 `native/oil-cold.json`、`native/oil-warm.json`、`native/oil-rated.json` をそれぞれ開く | A・Bの個別給油枝と圧力点、暖機に伴う流量変化、冷間の流量不足。ポンプ作動点の比較は `rated/oil.json` |
| RotorLab | `rotor`。 `native/rotor.json` を読み込む | 遠心2段と軸流3段の計5円板。給油側と同じ軸受A・B、回転数別係数と同期応答 |
| スラスト・軸締結 | Cycle Studioの設計アプリ連携、軸締結画面。 `native/spline.json`、`native/curvic.json` | 共通軸座標での荷重位置、軸受Bのスラスト反力、継手の荷重と強度 |

### 再計算時の目安

| 項目 | 参照値 |
|---|---:|
| 冷却後の正味発電出力 | 71.170 kW |
| 二次空気の注入流量合計 | 0.013562 kg/s |
| 軸受Bの給油流量（冷間／暖機／定格） | 2.607／3.545／7.360 L/min |
| RotorLabの確認回転数での同期応答片振幅 | 1.659 µm |
| 翼形状と計算値の照合断面 | 27 |

冷間の流量不足は、必要流量4.5 L/minに対する不足判定を確認するために残しています。

### 同じ入力で定格通し計算をやり直す

`rated/execution.json` には実行時の条件とハッシュがあり、`rated/request-*.json` には工程に渡した入力があります。共通フォルダーから次を実行し、空いている新規出力先を指定します。

```powershell
$sample = (Resolve-Path 'artifacts/gas-turbine-sample-20261128').Path
$modeId = (Get-Content -LiteralPath "$sample/design-desk-project.json" -Raw | ConvertFrom-Json).project.mbse.modes |
    Where-Object name -eq '定格発電' | Select-Object -ExpandProperty id
python -m gas_turbine_cycle_app.tools.suite_design_point --demo --project "$sample/design-desk-project.json" --mode-id $modeId --cycle-input "$sample/cycle-input.json" --settings-dir "$sample/settings" --output artifacts/gt-sample-01-rerun
```

個別アプリのファイルは再計算済みです。定格の抽気を連成し直す場合は、`rated/cycle-before-cooling.json` と、その入力ハッシュに対応する `rated/turbine.json` を組み合わせます。両者には燃焼器の再計算後の条件が含まれます。

新しいサンプル台帳と一式を生成する場合は、共通フォルダーで `python -m gas_turbine_cycle_app.tools.build_suite_sample --output artifacts/gt-sample-01-new` を実行します。新しい案件IDが発行されます。

## 確認の範囲

`shaft-layout.json` に共通軸上の翼車・支持位置があります。遠心翼車とタービンロータの軸方向配置は各形状の評価断面に基づきます。燃焼器まわりの軸方向間隔、円板の質量・慣性、軸受係数、材料・許容値は仮定値です。断面照合の軸流全圧はタービン単体モデル、冷却連携後の全圧は `rated/cooling.json` の段比較にあります。照合結果とファイルのSHA-256は `verification.json`、各アプリのCLI・HTTP API・形状計算で再現した値は `native-entry-checks.json` にあります。外部CAD・CFD・FEM、実機試験、全画面の手動操作は対象外です。
